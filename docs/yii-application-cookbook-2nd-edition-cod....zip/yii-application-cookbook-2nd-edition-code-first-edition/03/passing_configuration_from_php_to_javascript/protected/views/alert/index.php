<script>
	if(config && config.alert && config.alert.enabled && config.alert.message){
		alert(config.alert.message);
	}
</script>