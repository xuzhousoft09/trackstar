<?php
return array(
	'application.models.*',
	'application.components.*',
);
