<?php
return array(
	// this is used in contact page
	'adminEmail'=>'webmaster@example.com',
);
