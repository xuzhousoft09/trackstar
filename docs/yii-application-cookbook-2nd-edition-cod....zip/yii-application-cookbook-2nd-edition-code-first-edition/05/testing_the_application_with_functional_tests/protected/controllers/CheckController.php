<?php
class CheckController extends Controller
{
	function actionIndex()
	{
		$this->render('index');
	}
}
