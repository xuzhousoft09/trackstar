CREATE TABLE `article` (
  `alias` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`alias`)
);
