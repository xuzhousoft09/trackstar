<?php
class LyricsFinder
{
	public function getText($song)
	{
		return "Text for ".$song;
	}
}
