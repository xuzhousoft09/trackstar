Yii Application Development Cookbook 2nd Edition code
=====================================================

This repository contains the code of the second edition of
Yii Application Development Cookbook, the book containing various usable recipes
about Yii framework written by Alexander Makarov.

Root level directories are chapter numbers.

You can find more about the book at [yiicookbook.org](http://yiicookbook.org/).